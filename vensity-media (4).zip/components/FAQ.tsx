import React, { useState, forwardRef } from 'react';
import { FAQ_DATA } from '../constants';
import AnimatedHeading from './AnimatedHeading';

const FaqItem: React.FC<{ item: typeof FAQ_DATA[0], isOpen: boolean, onClick: () => void }> = ({ item, isOpen, onClick }) => {
    return (
        <div className="relative bg-white/5 border border-white/10 rounded-2xl overflow-hidden transition-all duration-300 aurora-border">
            <button
                onClick={onClick}
                className="w-full text-left flex justify-between items-center p-6"
                aria-expanded={isOpen}
            >
                <h3 className="text-lg font-semibold">{item.question}</h3>
                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className={`flex-shrink-0 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}
                >
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
            </button>
            <div
                className="grid transition-all duration-500 ease-in-out"
                style={{
                    gridTemplateRows: isOpen ? '1fr' : '0fr',
                }}
            >
                <div className="overflow-hidden">
                    <p className="text-gray-400 p-6 pt-0 leading-relaxed">
                        {item.answer}
                    </p>
                </div>
            </div>
        </div>
    );
};

const FAQ = forwardRef<HTMLElement>((props, ref) => {
    const [openIndex, setOpenIndex] = useState<number | null>(0);

    const handleItemClick = (index: number) => {
        setOpenIndex(openIndex === index ? null : index);
    };

    return (
        <section id="faq" className="py-24 sm:py-32" ref={ref}>
            <div className="container mx-auto px-6 text-center">
                <div className="mb-16">
                     <div className="inline-block bg-purple-500/10 text-purple-300 text-sm font-bold px-4 py-1.5 rounded-full mb-3 border border-purple-500/20">
                        ОТВЕТЫ НА ВОПРОСЫ
                    </div>
                    <AnimatedHeading text="Часто задаваемые вопросы" />
                    <p className="text-lg text-gray-400 max-w-3xl mx-auto">
                        Всё, что вы хотели знать, но боялись спросить.
                    </p>
                </div>
                <div className="max-w-3xl mx-auto space-y-4">
                    {FAQ_DATA.map((item, index) => (
                        <FaqItem
                            key={index}
                            item={item}
                            isOpen={openIndex === index}
                            onClick={() => handleItemClick(index)}
                        />
                    ))}
                </div>
            </div>
        </section>
    );
});

export default FAQ;