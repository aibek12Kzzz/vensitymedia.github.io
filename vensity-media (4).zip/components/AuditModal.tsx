import React, { useState, useEffect, useRef } from 'react';

interface AuditModalProps {
    isOpen: boolean;
    onClose: () => void;
}

const AuditModal: React.FC<AuditModalProps> = ({ isOpen, onClose }) => {
    const [name, setName] = useState('');
    const [instagram, setInstagram] = useState('');
    const [contact, setContact] = useState('');
    const modalRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (!isOpen) return;

        const modalNode = modalRef.current;
        if (!modalNode) return;
        
        const focusableElements = modalNode.querySelectorAll<HTMLElement>(
            'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];

        const handleTabKeyPress = (event: KeyboardEvent) => {
            if (event.key === 'Tab') {
                if (event.shiftKey) {
                    if (document.activeElement === firstElement) {
                        lastElement.focus();
                        event.preventDefault();
                    }
                } else {
                    if (document.activeElement === lastElement) {
                        firstElement.focus();
                        event.preventDefault();
                    }
                }
            }
        };
        
        const handleEsc = (event: KeyboardEvent) => {
            if (event.key === 'Escape') {
                onClose();
            }
        };
        
        firstElement?.focus();
        modalNode.addEventListener('keydown', handleTabKeyPress);
        window.addEventListener('keydown', handleEsc);

        return () => {
            modalNode.removeEventListener('keydown', handleTabKeyPress);
            window.removeEventListener('keydown', handleEsc);
        };
    }, [isOpen, onClose]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const phoneNumber = '77001040012';
        const fullMessage = `Здравствуйте! Vensity Media\n\nЯ хочу получить бесплатный экспресс-аудит.\n\n*Имя:* ${name}\n*Instagram:* @${instagram.replace('@', '')}\n*Контакт (WhatsApp/Telegram):* ${contact}`;
        const encodedMessage = encodeURIComponent(fullMessage);
        const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
        
        window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="modal-overlay" onClick={onClose}>
            <div
                ref={modalRef}
                className="modal-content bg-[#0A071A]/80 backdrop-blur-2xl border border-white/10 rounded-3xl w-[90vw] max-w-lg p-8 md:p-12"
                onClick={(e) => e.stopPropagation()}
                role="dialog"
                aria-modal="true"
                aria-labelledby="audit-modal-title"
            >
                <div className="text-center">
                    <h2 id="audit-modal-title" className="text-3xl font-bold mb-2">🔥 Бесплатный Аудит</h2>
                    <p className="text-gray-400 mb-6">Заполните форму, и мы свяжемся с вами в течение 24 часов с готовыми рекомендациями.</p>
                </div>
                <form className="space-y-6" onSubmit={handleSubmit}>
                    <div>
                        <label htmlFor="audit-name" className="block text-sm font-bold mb-2 text-gray-300">Имя</label>
                        <input 
                            type="text" 
                            id="audit-name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="form-input w-full bg-black/20 border border-white/10 rounded-lg px-4 py-3"
                            placeholder="Ваше имя" 
                            required 
                        />
                    </div>
                    <div>
                        <label htmlFor="audit-instagram" className="block text-sm font-bold mb-2 text-gray-300">Ваш Instagram</label>
                        <div className="relative">
                            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">@</span>
                            <input 
                                type="text" 
                                id="audit-instagram" 
                                value={instagram}
                                onChange={(e) => setInstagram(e.target.value)}
                                className="form-input w-full bg-black/20 border border-white/10 rounded-lg pl-8 pr-4 py-3"
                                placeholder="vash_profil" 
                                required 
                            />
                        </div>
                    </div>
                    <div>
                        <label htmlFor="audit-contact" className="block text-sm font-bold mb-2 text-gray-300">WhatsApp / Telegram</label>
                        <input 
                            type="text" 
                            id="audit-contact" 
                             value={contact}
                            onChange={(e) => setContact(e.target.value)}
                            className="form-input w-full bg-black/20 border border-white/10 rounded-lg px-4 py-3"
                            placeholder="Ваш номер или username" 
                            required 
                        />
                    </div>
                    <button type="submit" data-cursor-hover data-cursor-magnetic className="cta-gradient-hover w-full py-4 bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 text-white font-bold rounded-full shadow-lg shadow-purple-500/40 hover:scale-105 transform transition">
                        Получить аудит
                    </button>
                </form>
            </div>
        </div>
    );
};

export default AuditModal;