import React, { useState, forwardRef } from 'react';
import { SERVICES, ServiceIcon } from '../constants';
import TiltCard from './TiltCard';
import AnimatedHeading from './AnimatedHeading';


const ServiceCard: React.FC<{ service: typeof SERVICES[0], isCenter: boolean }> = ({ service, isCenter }) => (
     <div className={`relative bg-white/5 backdrop-blur-lg p-8 rounded-3xl border border-white/10 group transition-all duration-300 overflow-hidden h-full flex flex-col aurora-background ${isCenter ? 'aurora-shadow' : 'opacity-60 scale-90'}`}>
        <div className="w-20 h-20 mb-6 flex items-center justify-center bg-gradient-to-br from-purple-600 via-pink-600 to-cyan-500 rounded-2xl shadow-lg shadow-purple-500/30 group-hover:scale-110 transition-transform duration-300 animate-float">
            <ServiceIcon name={service.icon} />
        </div>
        <h3 className="text-2xl font-bold mb-3">{service.title}</h3>
        <p className="text-gray-400 leading-relaxed flex-grow">{service.description}</p>
    </div>
);

const Services = forwardRef<HTMLElement>((props, ref) => {
    const [currentIndex, setCurrentIndex] = useState(0);

    const handlePrev = () => {
        setCurrentIndex(prev => (prev === 0 ? SERVICES.length - 1 : prev - 1));
    };

    const handleNext = () => {
        setCurrentIndex(prev => (prev === SERVICES.length - 1 ? 0 : prev + 1));
    };

    const getCardStyle = (index: number) => {
        const offset = index - currentIndex;
        let rotateY = offset * 25;
        let translateX = offset * 70;
        let translateZ = -Math.abs(offset) * 150;
        let opacity = 1;
        let zIndex = SERVICES.length - Math.abs(offset);

        if (Math.abs(offset) > 2) {
            opacity = 0;
            translateX = offset > 0 ? 210 : -210;
        }

        return {
            transform: `translateX(${translateX}%) rotateY(${rotateY}deg) translateZ(${translateZ}px)`,
            opacity,
            zIndex,
        };
    };

    return (
        <section id="services" className="py-24 sm:py-32" ref={ref}>
            <div className="container mx-auto px-6 text-center">
                <div className="mb-24">
                    <div className="inline-block bg-purple-500/10 text-purple-300 text-sm font-bold px-4 py-1.5 rounded-full mb-3 border border-purple-500/20">
                        ЧТО МЫ ДЕЛАЕМ
                    </div>
                    <AnimatedHeading text="Наши Услуги" />
                    <p className="text-lg text-gray-400 max-w-3xl mx-auto">
                        Комплексное решение для всех ваших потребностей в цифровом маркетинге.
                    </p>
                </div>
                <div className="relative flex justify-center items-center h-[450px]">
                    <div className="carousel-container w-full h-full">
                         <div className="carousel" style={{ transform: `rotateY(0deg)` }}>
                            {SERVICES.map((service, index) => (
                                <div className="carousel-card" key={service.title} style={getCardStyle(index)} onClick={() => setCurrentIndex(index)}>
                                    <TiltCard>
                                        <ServiceCard service={service} isCenter={index === currentIndex} />
                                    </TiltCard>
                                </div>
                            ))}
                        </div>
                    </div>
                    <button data-cursor-magnetic onClick={handlePrev} className="absolute left-0 md:-left-10 z-50 bg-white/10 p-3 rounded-full hover:bg-white/20 transition-colors">
                         <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
                    </button>
                    <button data-cursor-magnetic onClick={handleNext} className="absolute right-0 md:-right-10 z-50 bg-white/10 p-3 rounded-full hover:bg-white/20 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </button>
                </div>
            </div>
        </section>
    );
});

export default Services;