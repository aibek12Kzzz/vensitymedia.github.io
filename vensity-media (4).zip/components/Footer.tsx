import React from 'react';
import { SocialIcon } from '../constants';

interface FooterProps {
    onScrollToServices: () => void;
    onScrollToPricing: () => void;
    onScrollToTestimonials: () => void;
    onScrollToFaq: () => void;
    onScrollToContact: () => void;
}

const FooterLink: React.FC<{ onClick: () => void; children: React.ReactNode }> = ({ onClick, children }) => (
    <li>
        <button data-cursor-hover onClick={onClick} className="text-gray-400 hover:text-white transition-colors duration-300">{children}</button>
    </li>
);

const Footer: React.FC<FooterProps> = ({ onScrollToServices, onScrollToPricing, onScrollToTestimonials, onScrollToFaq, onScrollToContact }) => {
    return (
        <footer className="bg-black/50 border-t border-white/10">
            <div className="container mx-auto px-6 py-16">
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
                    <div className="md:col-span-2 lg:col-span-1">
                        <div className="mb-4">
                           <span className="text-3xl font-bold bg-gradient-to-r from-[#6A25FF] via-pink-500 to-cyan-400 text-transparent bg-clip-text">
                                Vensity
                            </span>
                        </div>
                        <p className="text-gray-400">
                            SMM-агентство нового поколения, ориентированное на результат через стратегию, визуал и аналитику.
                        </p>
                    </div>
                    <div>
                        <h4 className="font-bold text-lg mb-4">Навигация</h4>
                        <ul className="space-y-3">
                            <FooterLink onClick={onScrollToServices}>Услуги</FooterLink>
                            <FooterLink onClick={onScrollToPricing}>Тарифы</FooterLink>
                            <FooterLink onClick={onScrollToTestimonials}>Отзывы</FooterLink>
                            <FooterLink onClick={onScrollToFaq}>FAQ</FooterLink>
                            <FooterLink onClick={onScrollToContact}>Контакты</FooterLink>
                        </ul>
                    </div>
                    <div>
                        <h4 className="font-bold text-lg mb-4">Компания</h4>
                        <ul className="space-y-3">
                            <li><button data-cursor-hover className="text-gray-400 hover:text-white transition-colors duration-300">О нас</button></li>
                            <li><button data-cursor-hover className="text-gray-400 hover:text-white transition-colors duration-300">Блог</button></li>
                            <li><button data-cursor-hover className="text-gray-400 hover:text-white transition-colors duration-300">Карьера</button></li>
                        </ul>
                    </div>
                    <div>
                         <h4 className="font-bold text-lg mb-4">Мы в соцсетях</h4>
                         <div className="flex space-x-4">
                            <a data-cursor-hover href="https://www.instagram.com/vensitymedia?igsh=MTRtN3FlNjRidWlvYw%3D%3D&utm_source=qr" target="_blank" rel="noopener noreferrer" className="w-10 h-10 flex items-center justify-center bg-white/5 rounded-lg hover:bg-gradient-to-br hover:from-purple-500 hover:to-pink-500 hover:scale-110 transition-all">
                                <SocialIcon name="instagram" />
                            </a>
                             <a data-cursor-hover href="https://t.me/vensitymedia" target="_blank" rel="noopener noreferrer" className="w-10 h-10 flex items-center justify-center bg-white/5 rounded-lg hover:bg-gradient-to-br hover:from-purple-500 hover:to-pink-500 hover:scale-110 transition-all">
                                <SocialIcon name="telegram" />
                            </a>
                             <a data-cursor-hover href="https://wa.me/77001040012" target="_blank" rel="noopener noreferrer" className="w-10 h-10 flex items-center justify-center bg-white/5 rounded-lg hover:bg-gradient-to-br hover:from-purple-500 hover:to-pink-500 hover:scale-110 transition-all">
                                <SocialIcon name="whatsapp" />
                            </a>
                         </div>
                    </div>
                </div>
            </div>
            <div className="border-t border-white/10 py-6 text-center text-gray-500">
                &copy; {new Date().getFullYear()} Vensity Media. Все права защищены.
            </div>
        </footer>
    );
};

export default Footer;