import React, { useEffect, useRef } from 'react';

const CustomCursor: React.FC = () => {
    const cursorRef = useRef<HTMLDivElement>(null);
    const animationFrameRef = useRef<number | null>(null);
    const lastPos = useRef({ x: 0, y: 0 });
    const currentPos = useRef({ x: 0, y: 0 });
    const magneticElements = useRef<HTMLElement[]>([]);

    useEffect(() => {
        magneticElements.current = Array.from(document.querySelectorAll('[data-cursor-magnetic]'));

        const moveCursor = (e: MouseEvent) => {
            currentPos.current = { x: e.clientX, y: e.clientY };
        };

        const animate = () => {
            lastPos.current.x += (currentPos.current.x - lastPos.current.x) * 0.2;
            lastPos.current.y += (currentPos.current.y - lastPos.current.y) * 0.2;

            if (cursorRef.current) {
                cursorRef.current.style.left = `${lastPos.current.x}px`;
                cursorRef.current.style.top = `${lastPos.current.y}px`;
            }

            // Magnetic effect logic
            for (const el of magneticElements.current) {
                const rect = el.getBoundingClientRect();
                const centerX = rect.left + rect.width / 2;
                const centerY = rect.top + rect.height / 2;
                const distance = Math.sqrt(Math.pow(centerX - lastPos.current.x, 2) + Math.pow(centerY - lastPos.current.y, 2));

                let scale = 1;
                // JS now manages the scale effect for elements with this class when hovered
                if (el.matches(':hover') && el.className.includes('hover:scale-105')) {
                    scale = 1.05;
                }

                if (distance < rect.width * 1.5) { // Activation distance
                    const dx = lastPos.current.x - centerX;
                    const dy = lastPos.current.y - centerY;
                    el.style.transform = `translate(${dx * 0.2}px, ${dy * 0.2}px) scale(${scale})`;
                } else {
                    // When not in magnetic range, still manage scale on hover
                    el.style.transform = `translate(0, 0) scale(${scale})`;
                }
            }
            
             if (cursorRef.current) {
                const target = document.elementFromPoint(currentPos.current.x, currentPos.current.y) as HTMLElement;
                 if (target && target.closest('[data-cursor-hover]')) {
                    cursorRef.current.classList.add('hovered');
                } else {
                    cursorRef.current.classList.remove('hovered');
                }
            }


            animationFrameRef.current = requestAnimationFrame(animate);
        };

        window.addEventListener('mousemove', moveCursor);
        animationFrameRef.current = requestAnimationFrame(animate);

        return () => {
            window.removeEventListener('mousemove', moveCursor);
            if (animationFrameRef.current) {
                cancelAnimationFrame(animationFrameRef.current);
            }
             for (const el of magneticElements.current) {
                el.style.transform = 'translate(0, 0)';
            }
        };
    }, []);

    return <div id="custom-cursor" ref={cursorRef} />;
};

export default CustomCursor;