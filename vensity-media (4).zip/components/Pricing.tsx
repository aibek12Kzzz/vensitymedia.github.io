import React, { useState, forwardRef } from 'react';
import { PRICING_PLANS } from '../constants';
import TiltCard from './TiltCard';
import AnimatedHeading from './AnimatedHeading';

type BillingCycle = 'monthly' | 'quarterly';

interface PricingCardProps {
    plan: typeof PRICING_PLANS[0];
    billingCycle: BillingCycle;
    onSelect: (planName: string) => void;
}

const CheckIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="text-purple-400 mr-3 flex-shrink-0">
        <polyline points="20 6 9 17 4 12"></polyline>
    </svg>
);

const PricingCard: React.FC<PricingCardProps> = ({ plan, billingCycle, onSelect }) => {
    const price = billingCycle === 'quarterly' && plan.price.quarterly ? plan.price.quarterly : plan.price.monthly;
    const periodText = billingCycle === 'quarterly' && plan.price.quarterly ? '₸ / мес. (квартал)' : '₸ / мес.';
    const hasDiscount = billingCycle === 'quarterly' && plan.price.quarterly;

    return (
        <TiltCard>
            <div className={`relative bg-white/5 backdrop-blur-lg p-8 rounded-3xl border ${plan.isPopular ? 'border-purple-500/80 aurora-shadow' : 'border-white/10'} transition-all duration-300 flex flex-col h-full`}>
                {plan.isPopular && (
                    <div className="absolute top-0 right-8 -translate-y-1/2 bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 px-4 py-1.5 rounded-full text-sm font-bold shadow-lg shadow-purple-500/50">
                        Популярный
                    </div>
                )}
                <div className="text-center">
                    <div className="text-6xl mb-4 animate-float" style={{animationDelay: `${Math.random() * 2}s`}}>{plan.emoji}</div>
                    <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                    <div className="h-24 flex flex-col justify-center">
                        {hasDiscount && (
                            <p className="text-gray-400 line-through">{plan.price.monthly} ₸ / мес.</p>
                        )}
                        <p className="text-5xl font-extrabold my-2">
                            <span className="bg-gradient-to-r from-purple-400 via-pink-500 to-cyan-400 text-transparent bg-clip-text">
                                {price}
                            </span>
                        </p>
                         <p className="text-lg text-gray-400 font-medium">{periodText}</p>
                    </div>
                </div>
                <ul className="space-y-4 my-8 flex-grow">
                    {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-start">
                            <CheckIcon />
                            <span className="text-gray-300">{feature}</span>
                        </li>
                    ))}
                </ul>
                <button
                    onClick={() => onSelect(plan.name)}
                    className={`w-full block text-center mt-auto py-3 font-bold rounded-full transition-all duration-300 ${plan.isPopular ? 'bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 text-white shadow-lg shadow-purple-500/40 hover:scale-105' : 'bg-white/10 hover:bg-white/20'}`}
                >
                    Выбрать пакет
                </button>
            </div>
        </TiltCard>
    );
};

interface PricingProps {
    onPlanSelect: (planName: string) => void;
}

const Pricing = forwardRef<HTMLElement, PricingProps>(({ onPlanSelect }, ref) => {
    const [billingCycle, setBillingCycle] = useState<BillingCycle>('monthly');

    return (
        <section id="pricing" className="py-24 sm:py-32" ref={ref}>
            <div className="container mx-auto px-6 text-center">
                <AnimatedHeading text="Выберите свой тариф" />
                <p className="text-lg text-gray-400 max-w-3xl mx-auto mb-12">
                    Простые и прозрачные тарифы для бизнеса любого размера.
                </p>

                <div className="flex justify-center mb-16">
                    <div className="relative flex items-center bg-black/20 p-1.5 rounded-full border border-white/10">
                         <span className={`absolute top-1/2 -translate-y-1/2 left-1.5 w-[calc(50%-0.375rem)] h-[calc(100%-0.75rem)] bg-purple-600/50 rounded-full transition-transform duration-300 ease-in-out ${billingCycle === 'quarterly' ? 'translate-x-full' : 'translate-x-0'}`}></span>
                         <button onClick={() => setBillingCycle('monthly')} className="relative z-10 px-6 py-2 rounded-full font-semibold transition-colors duration-300">
                             <span className={`${billingCycle === 'monthly' ? 'text-white' : 'text-gray-400'}`}>Ежемесячно</span>
                         </button>
                         <button onClick={() => setBillingCycle('quarterly')} className="relative z-10 px-6 py-2 rounded-full font-semibold transition-colors duration-300">
                             <span className={`${billingCycle === 'quarterly' ? 'text-white' : 'text-gray-400'}`}>Ежеквартально</span>
                             <div className="absolute -top-3 -right-2 transform transition-opacity duration-300">
                                 <span className="bg-pink-500/80 text-white text-xs font-bold px-2 py-1 rounded-md">-15%</span>
                            </div>
                         </button>
                    </div>
                </div>

                <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto items-stretch">
                    {PRICING_PLANS.map(plan => (
                        <PricingCard key={plan.name} plan={plan} billingCycle={billingCycle} onSelect={onPlanSelect} />
                    ))}
                </div>
            </div>
        </section>
    );
});

export default Pricing;