import React from 'react';
import { WORK_PROCESS_STEPS, ServiceIcon } from '../constants';
import AnimatedHeading from './AnimatedHeading';

const WorkProcess: React.FC = () => {
    return (
        <section className="py-24 sm:py-32">
            <div className="container mx-auto px-6">
                <div className="text-center mb-16">
                    <div className="inline-block bg-cyan-500/10 text-cyan-300 text-sm font-bold px-4 py-1.5 rounded-full mb-3 border border-cyan-500/20">
                        НАШ ПОДХОД
                    </div>
                    <AnimatedHeading text="Как мы работаем" />
                    <p className="text-lg text-gray-400 max-w-3xl mx-auto">
                        Прозрачный и структурированный процесс для достижения максимальных результатов.
                    </p>
                </div>

                <div className="relative max-w-2xl mx-auto">
                    {/* Vertical line */}
                    <div className="absolute left-6 md:left-1/2 -translate-x-1/2 top-0 h-full w-0.5 bg-gradient-to-b from-transparent via-purple-500/50 to-transparent"></div>

                    <div className="space-y-16">
                        {WORK_PROCESS_STEPS.map((step, index) => (
                            <div key={index} className="relative flex items-start">
                                <div className="z-10 w-12 h-12 flex-shrink-0 flex items-center justify-center bg-black/30 backdrop-blur-sm border-2 border-purple-500 rounded-full md:absolute md:left-1/2 md:-translate-x-1/2">
                                    <span className="text-purple-300 font-bold text-lg">{index + 1}</span>
                                </div>
                                <div className={`pl-8 md:pl-0 w-full ${index % 2 === 0 ? 'md:pr-16 md:text-right' : 'md:pl-16 md:text-left'}`}>
                                      <div className={`flex items-center gap-4 mb-2 ${index % 2 === 0 ? 'md:justify-end' : 'md:justify-start'}`}>
                                        <div className={`p-3 bg-purple-500/10 rounded-xl border border-purple-500/20 hidden md:block ${index % 2 !== 0 ? 'order-first' : ''}`}>
                                            <ServiceIcon name={step.icon} />
                                        </div>
                                        <h3 className="text-2xl font-bold">{step.title}</h3>
                                    </div>
                                    <p className="text-gray-400">{step.description}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
};

export default WorkProcess;
