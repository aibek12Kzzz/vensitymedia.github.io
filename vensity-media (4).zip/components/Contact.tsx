import React, { useState, useEffect, forwardRef } from 'react';
import { ContactIcon } from '../constants';
import AnimatedHeading from './AnimatedHeading';

const ContactInfoItem: React.FC<{ icon: React.ReactNode, title: string, detail: string, link: string }> = ({ icon, title, detail, link }) => (
    <div className="flex items-center space-x-4">
        <div className="w-16 h-16 flex-shrink-0 flex items-center justify-center bg-purple-500/10 border border-purple-500/20 rounded-2xl">
            {icon}
        </div>
        <div>
            <h4 className="text-xl font-bold">{title}</h4>
            <a href={link} className="text-gray-400 transition-colors hover:text-white">{detail}</a>
        </div>
    </div>
);

interface ContactProps {
    selectedPlan: string;
}

const Contact = forwardRef<HTMLElement, ContactProps>(({ selectedPlan }, ref) => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [message, setMessage] = useState('');

    useEffect(() => {
        if (selectedPlan) {
            setMessage(`Здравствуйте! Меня интересует тариф "${selectedPlan}".`);
        }
    }, [selectedPlan]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const phoneNumber = '77001040012';
        const fullMessage = `Здравствуйте! Vensity Media\n\n*Имя:* ${name}\n*Почта:* ${email}\n\n*Сообщение:*\n${message}`;
        const encodedMessage = encodeURIComponent(fullMessage);
        const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
        
        window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    };

    return (
        <section id="contact" className="py-24 sm:py-32" ref={ref}>
            <div className="container mx-auto px-6">
                <div className="grid lg:grid-cols-2 gap-16 items-center">
                    <div className="space-y-12">
                        <div>
                            <div className="inline-block bg-purple-500/10 text-purple-300 text-sm font-bold px-4 py-1.5 rounded-full mb-3 border border-purple-500/20">
                                СВЯЖИТЕСЬ С НАМИ
                            </div>
                           <AnimatedHeading text="Наши Контакты" align="left" />
                        </div>
                        <ContactInfoItem 
                            icon={<ContactIcon name="mail" />} 
                            title="Почта" 
                            detail="vensitymedia@gmail.com"
                            link="mailto:vensitymedia@gmail.com"
                        />
                        <ContactInfoItem 
                            icon={<ContactIcon name="phone" />} 
                            title="Телефон" 
                            detail="+7 (700) 104-0012"
                            link="tel:+77001040012"
                        />
                        <ContactInfoItem 
                            icon={<ContactIcon name="map" />} 
                            title="Адрес" 
                            detail="Алматы, Казахстан"
                            link="#"
                        />
                    </div>
                    <div className="relative bg-white/5 backdrop-blur-lg border border-white/10 p-8 sm:p-12 rounded-3xl aurora-shadow">
                        <form className="space-y-6" onSubmit={handleSubmit}>
                            <div>
                                <label htmlFor="name" className="block text-sm font-bold mb-2 text-gray-300">Имя</label>
                                <input 
                                    type="text" 
                                    id="name" 
                                    value={name}
                                    onChange={(e) => setName(e.target.value)}
                                    className="form-input w-full bg-black/20 border border-white/10 rounded-lg px-4 py-3" 
                                    placeholder="Ваше имя" 
                                    required 
                                />
                            </div>
                            <div>
                                <label htmlFor="email" className="block text-sm font-bold mb-2 text-gray-300">Почта</label>
                                <input 
                                    type="email" 
                                    id="email" 
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    className="form-input w-full bg-black/20 border border-white/10 rounded-lg px-4 py-3" 
                                    placeholder="vash.email@example.com" 
                                    required 
                                />
                            </div>
                            <div>
                                <label htmlFor="message" className="block text-sm font-bold mb-2 text-gray-300">Сообщение</label>
                                <textarea 
                                    id="message" 
                                    rows={4} 
                                    value={message}
                                    onChange={(e) => setMessage(e.target.value)}
                                    className="form-input w-full bg-black/20 border border-white/10 rounded-lg px-4 py-3" 
                                    placeholder="Чем мы можем помочь?"
                                    required
                                ></textarea>
                            </div>
                            <button type="submit" className="w-full py-4 bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 text-white font-bold rounded-full shadow-lg shadow-purple-500/40 hover:scale-105 hover:shadow-xl hover:shadow-purple-500/60 transform transition-all duration-300 cta-gradient-hover">
                                Отправить сообщение
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    );
});

export default Contact;