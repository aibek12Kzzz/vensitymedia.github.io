import React, { useState, useEffect } from 'react';

interface HeaderProps {
    onScrollToServices: () => void;
    onScrollToPricing: () => void;
    onScrollToTestimonials: () => void;
    onScrollToFaq: () => void;
    onScrollToContact: () => void;
}

const NavLink: React.FC<{onClick: () => void, children: React.ReactNode, className?: string}> = ({ onClick, children, className }) => (
    <button data-cursor-hover data-cursor-magnetic onClick={onClick} className={`text-gray-300 hover:text-white transition-colors relative group ${className}`}>
        {children}
        <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-300 group-hover:w-full"></span>
    </button>
);


const Header: React.FC<HeaderProps> = ({ onScrollToServices, onScrollToPricing, onScrollToTestimonials, onScrollToFaq, onScrollToContact }) => {
    const [scrolled, setScrolled] = useState(false);
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    useEffect(() => {
        const handleScroll = () => {
            setScrolled(window.scrollY > 10);
        };
        window.addEventListener('scroll', handleScroll);
        
        // Prevent body scroll when mobile menu is open
        document.body.style.overflow = isMenuOpen ? 'hidden' : 'auto';
        
        return () => window.removeEventListener('scroll', handleScroll);
    }, [isMenuOpen]);

    const handleLinkClick = (scrollFunc: () => void) => {
      scrollFunc();
      setIsMenuOpen(false);
    }

    const navLinks = (
        <>
            <NavLink onClick={() => handleLinkClick(onScrollToServices)}>Услуги</NavLink>
            <NavLink onClick={() => handleLinkClick(onScrollToPricing)}>Тарифы</NavLink>
            <NavLink onClick={() => handleLinkClick(onScrollToTestimonials)}>Отзывы</NavLink>
            <NavLink onClick={() => handleLinkClick(onScrollToFaq)}>FAQ</NavLink>
            <NavLink onClick={() => handleLinkClick(onScrollToContact)}>Контакты</NavLink>
        </>
    );

    return (
        <>
            <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled || isMenuOpen ? 'bg-black/30 backdrop-blur-xl border-b border-white/10' : 'bg-transparent'}`}>
                <div className="container mx-auto px-6 py-4 flex justify-between items-center">
                    <div className="flex items-center" data-cursor-magnetic>
                        <span className="text-3xl font-bold bg-gradient-to-r from-[#6A25FF] via-pink-500 to-cyan-400 text-transparent bg-clip-text">
                            Vensity
                        </span>
                    </div>
                    <nav className="hidden md:flex items-center space-x-8">
                        {navLinks}
                    </nav>
                    <button data-cursor-hover data-cursor-magnetic onClick={() => handleLinkClick(onScrollToContact)} className="hidden md:block px-6 py-2 bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 text-white font-semibold rounded-full shadow-lg shadow-purple-500/40 hover:scale-105 hover:shadow-xl hover:shadow-purple-500/60 transform transition-all duration-300 cta-gradient-hover">
                        Начать работу
                    </button>
                    <div className="md:hidden">
                        <button data-cursor-hover onClick={() => setIsMenuOpen(!isMenuOpen)} className={`mobile-menu-toggle z-50 ${isMenuOpen ? 'open' : ''}`}>
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>
                </div>
            </header>
            
            {/* Mobile Menu Overlay */}
            <div className={`md:hidden fixed inset-0 bg-[#02000f]/80 backdrop-blur-lg z-40 transition-opacity duration-300 ${isMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
                 <nav className="flex flex-col items-center justify-center h-full space-y-8 text-2xl font-semibold">
                    {navLinks}
                     <button data-cursor-hover data-cursor-magnetic onClick={() => handleLinkClick(onScrollToContact)} className="mt-8 px-8 py-4 bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 text-white font-semibold rounded-full shadow-lg shadow-purple-500/40 cta-gradient-hover">
                        Начать работу
                    </button>
                </nav>
            </div>
        </>
    );
};

export default Header;