import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import AnimatedHeading from './AnimatedHeading';

const IdeaGenerator: React.FC = () => {
    const [niche, setNiche] = useState('');
    const [ideas, setIdeas] = useState<string[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleGenerateIdeas = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!niche.trim() || isLoading) return;

        setIsLoading(true);
        setError(null);
        setIdeas([]);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: `Ты - креативный SMM-менеджер. Придумай 5 коротких, вирусных идей для постов или Reels в Instagram для ниши: "${niche}". Каждая идея должна быть на новой строке и начинаться с эмодзи.`,
            });
            
            const text = response.text;
            const generatedIdeas = text.split('\n').filter(idea => idea.trim() !== '');
            setIdeas(generatedIdeas);

        } catch (err) {
            console.error("Error generating ideas:", err);
            setError("Не удалось сгенерировать идеи. Попробуйте еще раз.");
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <section className="py-24 sm:py-32">
            <div className="container mx-auto px-6 text-center">
                 <div className="mb-16">
                    <div className="inline-block bg-pink-500/10 text-pink-300 text-sm font-bold px-4 py-1.5 rounded-full mb-3 border border-pink-500/20">
                        ✨ ВАУ-ЭФФЕКТ
                    </div>
                    <AnimatedHeading text="AI-Генератор Идей" />
                    <p className="text-lg text-gray-400 max-w-3xl mx-auto">
                        Не знаете что постить? Введите свою нишу и получите креативные идеи от нашего AI-помощника!
                    </p>
                </div>
                <div className="relative max-w-2xl mx-auto bg-white/5 backdrop-blur-lg border border-white/10 p-8 rounded-3xl aurora-shadow">
                    <form onSubmit={handleGenerateIdeas} className="flex flex-col sm:flex-row gap-4">
                        <input
                            type="text"
                            value={niche}
                            onChange={(e) => setNiche(e.target.value)}
                            placeholder="Например, 'кофейня' или 'фитнес-клуб'"
                            className="flex-grow bg-black/20 border border-white/10 rounded-full px-6 py-4 focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none transition duration-300"
                            disabled={isLoading}
                        />
                        <button 
                            type="submit" 
                            className="px-8 py-4 bg-gradient-to-r from-pink-500 to-purple-500 text-white font-bold rounded-full shadow-lg shadow-pink-500/40 hover:scale-105 hover:shadow-xl hover:shadow-pink-500/60 transform transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                            disabled={isLoading || !niche.trim()}
                        >
                            {isLoading ? 'Генерация...' : 'Получить идеи'}
                        </button>
                    </form>
                    
                    <div className="mt-8 text-left min-h-[150px]">
                        {isLoading && (
                             <div className="flex justify-center items-center h-full">
                                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-400"></div>
                            </div>
                        )}
                        {error && <p className="text-red-400 text-center">{error}</p>}
                        {ideas.length > 0 && (
                            <ul className="space-y-3 list-inside">
                                {ideas.map((idea, index) => (
                                    <li key={index} className="p-3 bg-white/5 rounded-lg border border-white/10">
                                        {idea}
                                    </li>
                                ))}
                            </ul>
                        )}
                    </div>
                </div>
            </div>
        </section>
    );
};

export default IdeaGenerator;