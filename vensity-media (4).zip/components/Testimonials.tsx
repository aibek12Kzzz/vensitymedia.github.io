import React, { useState, useEffect, useCallback, forwardRef } from 'react';
import { TESTIMONIALS } from '../constants';
import TiltCard from './TiltCard';
import AnimatedHeading from './AnimatedHeading';

const Testimonials = forwardRef<HTMLElement>((props, ref) => {
    const [currentIndex, setCurrentIndex] = useState(0);

    const nextSlide = useCallback(() => {
        setCurrentIndex((prevIndex) =>
            prevIndex === TESTIMONIALS.length - 1 ? 0 : prevIndex + 1
        );
    }, []);

    const prevSlide = () => {
        setCurrentIndex((prevIndex) =>
            prevIndex === 0 ? TESTIMONIALS.length - 1 : prevIndex - 1
        );
    };

    useEffect(() => {
        const slideInterval = setInterval(nextSlide, 5000);
        return () => clearInterval(slideInterval);
    }, [nextSlide]);

    return (
        <section id="testimonials" className="py-24 sm:py-32" ref={ref}>
            <div className="container mx-auto px-6 text-center">
                <div className="mb-16">
                    <div className="inline-block bg-purple-500/10 text-purple-300 text-sm font-bold px-4 py-1.5 rounded-full mb-3 border border-purple-500/20">
                        ЧТО ГОВОРЯТ КЛИЕНТЫ
                    </div>
                    <AnimatedHeading text="Нам доверяют" />
                    <p className="text-lg text-gray-400 max-w-3xl mx-auto">
                        Реальные отзывы от компаний, которые уже достигли результатов с нами.
                    </p>
                </div>

                <div className="relative max-w-3xl mx-auto">
                     <TiltCard>
                        <div className="overflow-hidden relative h-80">
                            {TESTIMONIALS.map((testimonial, index) => (
                                <div
                                    key={index}
                                    className="absolute inset-0 transition-opacity duration-700 ease-in-out"
                                    style={{ opacity: index === currentIndex ? 1 : 0 }}
                                >
                                    <div className="relative bg-white/5 backdrop-blur-lg p-8 rounded-3xl border border-white/10 h-full flex flex-col justify-center items-center aurora-border">
                                        <div className="w-20 h-20 mb-4 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center text-2xl font-bold">
                                            {testimonial.avatar}
                                        </div>
                                        <blockquote className="text-lg italic text-gray-300 mb-4">
                                            "{testimonial.quote}"
                                        </blockquote>
                                        <footer className="font-bold">{testimonial.name}, <span className="text-purple-400">{testimonial.title}</span></footer>
                                    </div>
                                </div>
                            ))}
                        </div>
                     </TiltCard>

                    <button onClick={prevSlide} className="absolute top-1/2 -left-4 md:-left-16 transform -translate-y-1/2 bg-white/10 p-2 rounded-full hover:bg-white/20 transition-colors z-10">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
                    </button>
                    <button onClick={nextSlide} className="absolute top-1/2 -right-4 md:-right-16 transform -translate-y-1/2 bg-white/10 p-2 rounded-full hover:bg-white/20 transition-colors z-10">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </button>
                </div>
                 <div className="flex justify-center mt-8 space-x-2">
                    {TESTIMONIALS.map((_, index) => (
                        <button
                            key={index}
                            onClick={() => setCurrentIndex(index)}
                            className={`w-3 h-3 rounded-full transition-all duration-300 ${index === currentIndex ? 'bg-purple-500 scale-125' : 'bg-white/20'}`}
                            aria-label={`Go to slide ${index + 1}`}
                        />
                    ))}
                </div>
            </div>
        </section>
    );
});

export default Testimonials;