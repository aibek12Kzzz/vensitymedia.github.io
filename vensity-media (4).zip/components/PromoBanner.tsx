import React from 'react';

interface PromoBannerProps {
    onOpenAuditModal: () => void;
}

const PromoBanner: React.FC<PromoBannerProps> = ({ onOpenAuditModal }) => {
    return (
        <section className="py-20 my-16 bg-gradient-to-r from-purple-600 via-pink-600 to-cyan-500 relative overflow-hidden">
             <div 
                className="absolute inset-0 opacity-10 animate-move-grid" 
                style={{
                    backgroundImage: 'radial-gradient(white 0.5px, transparent 0.5px), radial-gradient(white 0.5px, transparent 0.5px)',
                    backgroundSize: '20px 20px',
                    backgroundPosition: '0 0, 10px 10px',
                }}
            ></div>
            <div className="container mx-auto px-6 text-center relative z-10 flex flex-col items-center">
                <h2 className="text-4xl md:text-5xl font-extrabold text-white drop-shadow-lg">🔥 Узнайте 3 точки роста вашего Instagram!</h2>
                <p className="mt-4 text-xl md:text-2xl text-white/90 max-w-3xl mx-auto drop-shadow-md">
                    Получите <span className="font-bold">бесплатный экспресс-аудит</span> от наших экспертов и конкретные рекомендации уже сегодня.
                </p>
                <button 
                    data-cursor-hover
                    onClick={onOpenAuditModal}
                    className="mt-8 px-8 py-4 bg-white/90 text-purple-700 font-bold rounded-full shadow-2xl shadow-white/30 hover:scale-105 hover:bg-white transform transition-all duration-300"
                >
                    Получить аудит бесплатно
                </button>
            </div>
        </section>
    );
};

export default PromoBanner;