import React, { useRef, MouseEvent } from 'react';

interface TiltCardProps {
    children: React.ReactNode;
}

const TiltCard: React.FC<TiltCardProps> = ({ children }) => {
    const cardRef = useRef<HTMLDivElement>(null);

    const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
        if (!cardRef.current) return;

        const { left, top, width, height } = cardRef.current.getBoundingClientRect();
        const x = e.clientX - left;
        const y = e.clientY - top;

        const rotateX = ((y / height) - 0.5) * -15; // Invert for natural feel
        const rotateY = ((x / width) - 0.5) * 15;

        cardRef.current.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.07)`;
        
        // Update glare effect position
        cardRef.current.style.setProperty('--glow-x', `${x}px`);
        cardRef.current.style.setProperty('--glow-y', `${y}px`);
    };

    const handleMouseLeave = () => {
        if (cardRef.current) {
            cardRef.current.style.transform = 'rotateX(0deg) rotateY(0deg) scale(1)';
        }
    };

    return (
        <div 
            className="preserve-3d w-full h-full"
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
        >
            <div ref={cardRef} className="tilt-card w-full h-full">
                {children}
            </div>
        </div>
    );
};

export default TiltCard;