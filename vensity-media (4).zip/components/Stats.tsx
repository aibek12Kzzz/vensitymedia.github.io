
import React, { useState, useEffect, useRef } from 'react';

const stats = [
    { value: '500+', label: 'Проектов' },
    { value: '98%', label: 'Довольных клиентов' },
    { value: '2+', label: 'Года опыта' },
    { value: '100%', label: 'Фокус на результат' },
];

const CountUp: React.FC<{ value: string; duration?: number }> = ({ value, duration = 2000 }) => {
    const [count, setCount] = useState(0);
    const ref = useRef<HTMLSpanElement>(null);
    const hasAnimated = useRef(false);
    
    const end = parseInt(value, 10);
    const suffix = value.replace(String(end), '');

    useEffect(() => {
        if (isNaN(end)) return;

        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting && !hasAnimated.current) {
                    hasAnimated.current = true;
                    let start = 0;
                    const startTime = Date.now();

                    const animate = () => {
                        const now = Date.now();
                        const progress = Math.min((now - startTime) / duration, 1);
                        const currentNum = Math.floor(progress * (end - start) + start);
                        setCount(currentNum);

                        if (progress < 1) {
                            requestAnimationFrame(animate);
                        } else {
                            setCount(end);
                        }
                    };
                    requestAnimationFrame(animate);
                }
            },
            { threshold: 0.1 }
        );

        const currentRef = ref.current;
        if (currentRef) {
            observer.observe(currentRef);
        }

        return () => {
            if (currentRef) {
                observer.unobserve(currentRef);
            }
        };
    }, [end, duration]);

    return (
        <span ref={ref}>
            {isNaN(end) ? value : `${count}${suffix}`}
        </span>
    );
};

const StatItem: React.FC<{ value: string; label: string; isLast?: boolean }> = ({ value, label, isLast }) => (
    <div className={`flex-1 text-center px-4 ${!isLast ? 'sm:border-r border-white/10' : ''}`}>
        <p className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-400 via-pink-500 to-cyan-400 text-transparent bg-clip-text">
            <CountUp value={value} />
        </p>
        <p className="mt-2 text-gray-400">{label}</p>
    </div>
);

const Stats: React.FC = () => {
    return (
        <section className="relative -mt-20 z-20">
            <div className="container mx-auto px-6">
                <div className="relative bg-black/30 backdrop-blur-xl rounded-3xl aurora-shadow aurora-border">
                    <div className="flex flex-col sm:flex-row justify-around items-center divide-y sm:divide-y-0 sm:divide-x-0 divide-white/10 p-8 space-y-6 sm:space-y-0">
                        {stats.map((stat, index) => (
                            <StatItem key={stat.label} value={stat.value} label={stat.label} isLast={index === stats.length - 1} />
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Stats;