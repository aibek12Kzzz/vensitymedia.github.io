import React from 'react';

interface AnimatedHeadingProps {
    text: string;
    align?: 'left' | 'center' | 'right';
}

const AnimatedHeading: React.FC<AnimatedHeadingProps> = ({ text, align = 'center' }) => {
    const alignClass = {
        left: 'text-left',
        center: 'text-center',
        right: 'text-right'
    }[align];

    return (
        <h2 className={`animated-heading text-4xl md:text-5xl font-extrabold mb-4 ${alignClass}`}>
            {text.split('').map((char, index) => (
                <span
                    key={index}
                    className="letter"
                    style={{ animationDelay: `${index * 0.03}s` }}
                >
                    {char === ' ' ? '\u00A0' : char}
                </span>
            ))}
        </h2>
    );
};

export default AnimatedHeading;
