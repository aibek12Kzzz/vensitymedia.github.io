import React, { useRef } from 'react';

interface HeroProps {
    onScrollToPricing: () => void;
}

const Hero: React.FC<HeroProps> = ({ onScrollToPricing }) => {
    const heroRef = useRef<HTMLElement>(null);

    return (
        <section ref={heroRef} className="relative min-h-screen flex items-center justify-center text-center overflow-hidden pt-32 pb-20 preserve-3d">
            {/* Animated Background Blobs */}
            <div className="absolute inset-0 z-0">
                <div className="absolute top-0 left-0 w-96 h-96 bg-purple-600 rounded-full filter blur-3xl opacity-20 animate-move-blob-1"></div>
                <div className="absolute bottom-0 right-0 w-96 h-96 bg-pink-600 rounded-full filter blur-3xl opacity-20 animate-move-blob-2"></div>
            </div>
            
            <div className="relative z-10 p-6 flex flex-col items-center">
                <div className="bg-purple-500/10 backdrop-blur-sm border border-purple-500/20 rounded-full px-4 py-1.5 mb-4 text-sm text-purple-200">
                    🚀 SMM-агентство нового поколения
                </div>
                <h1 className="text-5xl md:text-7xl lg:text-8xl font-black max-w-5xl leading-tight tracking-tighter">
                    Превращаем Instagram в Источник{' '}
                    <span className="bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 text-transparent bg-clip-text">
                        КЛИЕНТОВ
                    </span>
                </h1>
                <p className="mt-6 text-lg md:text-xl text-gray-300 max-w-2xl">
                    Стратегия + Сильный визуал + Глубокая аналитика = Система, которая превращает контент в прибыль.
                </p>
                <div className="mt-10 flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                    <button 
                        data-cursor-hover
                        onClick={onScrollToPricing}
                        className="block px-8 py-4 bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 text-white font-bold rounded-full shadow-lg shadow-purple-500/50 hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/70 transition-all duration-300 cta-gradient-hover">
                        Выбрать тариф →
                    </button>
                    <a data-cursor-hover href="https://wa.me/77001040012" target="_blank" rel="noopener noreferrer" className="block relative px-8 py-4 bg-black/20 text-white font-bold rounded-full backdrop-blur-sm overflow-hidden aurora-border hover:bg-white/10 transition-all duration-300">
                        Начать работу
                    </a>
                </div>
            </div>
        </section>
    );
};

export default Hero;